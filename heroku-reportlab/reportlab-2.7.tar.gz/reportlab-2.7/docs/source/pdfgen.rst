===================================
package reportlab.pdfgen
===================================

.. rubric:: The basics

module reportlab.pdfgen.canvas
------------------------------

.. automodule:: reportlab.pdfgen.canvas
   :members:
